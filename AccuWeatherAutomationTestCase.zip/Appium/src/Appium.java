import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;


import io.appium.java_client.ios.IOSDriver;
import org.junit.*;

public class Appium {
	
	static WebDriver driver;
	
	@BeforeClass
	public static void setup() throws MalformedURLException {
	DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
	
	desiredCapabilities.setCapability("platformVersion", "10.0");
	desiredCapabilities.setCapability("platformName", "iOS");
	desiredCapabilities.setCapability("deviceName", "Test iPhone");
	desiredCapabilities.setCapability("app", "C://pathtomyapp.apk");
	desiredCapabilities.setCapability("bundleId", "com.example.AccuWeather");
	

	driver = new IOSDriver<WebElement>(new URL("http://127.0.0.1:4723/wd/hub"), desiredCapabilities);
	driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	}
	
	
	@Test
	public void addNewLocation(){
	
	driver.findElement(By.id("add")).click();
	driver.findElement(By.id("input-new-city")).sendKeys("Ban");
	driver.findElement(By.id("Bangalore")).click(); 
	
	String actualLocationName = driver.findElement(By.name("current-city")).getText();
	String expectedLocationName = "Bangalore";
	Assert.assertEquals(actualLocationName, expectedLocationName);
	
	
	
	}
	
	@AfterClass
	 public static void teardown(){
		
		driver.quit();
		
	}
	
	
	
	
	}
	
	

